# @microfronts/contracts

Versioned props and cache keys shared by Shell, Catalog and Cart. No runtime stores,
HTTP operations or React contexts. Host creates one QueryClient per session lifecycle
and passes its reference to remotes. Standalone hosts create their own client.

Build with `npm pack`, copy the archive into each frontend's `vendor/`, then install
the local archive. Optional new props preserve the v2 host interface. Deploy remotes
before the new Shell, or deploy a coordinated version set. Never deploy the new Shell
with old remotes: those do not understand authenticated session scopes.
