import type { QueryClient } from '@tanstack/react-query';
export interface User { id: string; email: string; name: string }
export type Destination = 'catalog' | 'cart' | 'login' | 'account';
export interface RemoteProps {
  apiBaseUrl: string;
  cartKey: string;
  queryClient?: QueryClient;
  /** user:<id> or guest:<cartKey>; omitted in legacy/standalone hosts. */
  sessionScope?: string;
  onUnauthorized?: () => void;
  onNavigate?: (destination: Destination) => void;
}
export interface CatalogProps extends RemoteProps { onCartChanged?: () => void }
export interface CartProps extends RemoteProps { refreshVersion?: number }
export interface CartItem { productId: string; title: string; priceMinor: number; quantity: number }
export interface Cart { items: CartItem[]; totalMinor: number; currency: string; revision: number }
export interface Product { id: string; title: string; priceMinor: number; currency: string; badge?: string }
export function productsKey(api: string): readonly ['products', string];
export function cartKey(api: string, scope: string): readonly ['cart', string, string];
export function sessionKey(api: string): readonly ['session', string];
