export const productsKey = (api) => ['products', api];
export const cartKey = (api, scope) => ['cart', api, scope];
export const sessionKey = (api) => ['session', api];
